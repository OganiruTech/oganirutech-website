<?php

namespace App\Mail;

use App\Models\ContactMessage;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Address;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

/**
 * Internal alert: someone submitted the contact form.
 */
class ContactFormMail extends Mailable implements ShouldQueue
{
    use Queueable, SerializesModels;

    public int $tries = 3;

    public array $backoff = [60, 300, 900];

    public function __construct(
        public readonly ContactMessage $contact
    ) {}

    public function envelope(): Envelope
    {
        return new Envelope(
            from: new Address(config('oganiru.from_email'), config('oganiru.from_name')),
            replyTo: [new Address($this->contact->email)],
            subject: 'New contact form submission — '.config('oganiru.site_name'),
        );
    }

    public function content(): Content
    {
        return new Content(
            view: 'emails.contact',
            with: [
                'dashboardUrl' => route('admin.contacts.show', $this->contact->id),
            ],
        );
    }
}
